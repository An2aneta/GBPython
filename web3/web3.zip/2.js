const userName = prompt('Введите ваше имя:');
function greeting(userName){
    console.log(`Привет, ${userName}!`);
}
greeting(userName);